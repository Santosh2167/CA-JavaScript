var global = "this is a global var";

console.log(global);